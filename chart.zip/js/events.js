//Evento para seleccionar y procesar el archivo .csv
document.getElementById('fileInput').addEventListener('change', function(event) {
	const file = event.target.files[0];
	console.log(file)
	if (file) {
		//Analiza el csv y lo devuelve en una matriz bidimensional
		Papa.parse(file, {
			complete: function(results) {
				console.log(results)
				let header = results.data.slice(0,2)
				updateChartInformation(header)
				let data = results.data.slice(2)

				currentData = processCSV(data);
				means = calculateAllMean(currentData)
				calculateRange(currentData)
				filterData = currentData;
				updateChart(filterData);
			}
		});
	}
});

//Evento para seleccionar el tipo de cuadro
// document.getElementById('chartType').addEventListener('change', function() {
// 	const chartType = document.getElementById('chartType').value;
// 	if (filterData) {
// 		updateChart(filterData, chartType);
// 	}
// });

//Evento para seleccionar la fecha de inicio
// document.getElementById('startDate').addEventListener('change', function() {
// startDate = this.value
// 	filterData = filterDataByDate();
// 	updateChart(filterData)
// })

// //Evento para seleccionar la fecha de fin
// document.getElementById('endDate').addEventListener('change', function() {
// endDate = this.value
// 	filterData = filterDataByDate();
// 	updateChart(filterData)
// })